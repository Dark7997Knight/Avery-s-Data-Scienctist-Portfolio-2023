This data was collected by the National Ecological Observatory Network's (NEON) 
Airborne Observation Platform during yearly test flights. The post-processing 
to create the Digital Surface Models (DSMs) and Digital Terrain Models (DTMs) 
occurred at the NEON headquarters in Boulder, Colorado. 

The "pre" data was collected on June 26-27, 2013. The "post" data was collected
on October 8, 2013. A technical memo on this data collection can be found at http://www.neonscience.org/data-resources/papers-publications/tm-006-neon-aop-surveys-city-boulder-pre-post-2013-flood-event . NEON remote sensing data can be requested: http://www.neonscience.org/data-resources/get-data/airborne-data . 

The LocationsOfSignificantChange.kmz file is not used in the lesson and is supplemental.  It shows several regions around Boulder County that suffered significant damage in the 2013 flooding event. 
Note on teaching data subsets: 

805325-precip_daily_2003-2013.csv (downlaoded 13 Sept. 2016) is the primary data subset used in the teaching module. This data subset is in inches and has a NoData Value of 999.99. At this time the available documentation had not been updated (has values as hundredth of an inch and a NoData Value of 99999). 

804417-precip_daily_2003-2013_metric.csv (downloaded 12 Sept. 2016) is provided 
for those who prefer to use a dataset in metric. 
Note that this dataset appears to be in mm, not 10th of mm, and the NoData Value
is 25399.75, both different than in the provided
documentation. If using this dataset, the code for setting the NA values will 
have to be changed(25399.75, instead of 999.99). No other code will need to be 
changed. 

80533-precip-daily_2948-2013.csv (downloaded 14 Sept. 2016) is provided for those that want to expand the lesson beyond the decade approach focused on in this lesson or those that want to include the challenge activity in the lesson. 

The data subset 050843-precip_daily_2003-2013.csv was download Nov. 18, 2015. This 
data set has values in hundredth of an inch and a NoData Value of 
99999 matching the documentation in PRECIP_HLY_documentation.pdf (v. Feb. 2016). 
This data subset is retained for historical purposes. 